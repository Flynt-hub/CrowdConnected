var group__location_overlay_interface =
[
    [ "getCompassHeadingMarkerVisible", "group__location_overlay_interface_ga5ddb27392d238f4935d7211cc062ab12.html#ga5ddb27392d238f4935d7211cc062ab12", null ],
    [ "setCompassHeadingMarkerVisible", "group__location_overlay_interface_ga9df4d583c960dc914972aef782be81b4.html#ga9df4d583c960dc914972aef782be81b4", null ]
];