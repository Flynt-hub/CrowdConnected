var group__callbacks =
[
    [ "VMEAnimationCallback", "interfacecallbacks_1_1_v_m_e_animation_callback.html", [
      [ "didFinish", "interfacecallbacks_1_1_v_m_e_animation_callback_a0df3b0869859ae39dfb56d4bc61e8d8d.html#a0df3b0869859ae39dfb56d4bc61e8d8d", null ]
    ] ],
    [ "VMEComputeRouteCallback", "interfacecallbacks_1_1_v_m_e_compute_route_callback.html", [
      [ "computeRouteDidFail", "interfacecallbacks_1_1_v_m_e_compute_route_callback_a1aa4ff66d3a19cae559221008a09cda6.html#a1aa4ff66d3a19cae559221008a09cda6", null ],
      [ "computeRouteDidFinish", "interfacecallbacks_1_1_v_m_e_compute_route_callback_a2d96bb54919aad0081cc3425511bdfdb.html#a2d96bb54919aad0081cc3425511bdfdb", null ]
    ] ],
    [ "VMECustomDataRefreshCallback", "interfacecallbacks_1_1_v_m_e_custom_data_refresh_callback.html", [
      [ "refreshCustomDataDidFinish", "interfacecallbacks_1_1_v_m_e_custom_data_refresh_callback_afc0593a56802bdaedb185c477e31b70b.html#afc0593a56802bdaedb185c477e31b70b", null ]
    ] ],
    [ "VMEPlaceFilterCallback", "interfacecallbacks_1_1_v_m_e_place_filter_callback.html", [
      [ "placeFilterDidFinish", "interfacecallbacks_1_1_v_m_e_place_filter_callback_ac6d1ff55feb1c04ee7198edff230b255.html#ac6d1ff55feb1c04ee7198edff230b255", null ]
    ] ],
    [ "VMESearchViewCallback", "interfacecallbacks_1_1_v_m_e_search_view_callback.html", [
      [ "searchView", "interfacecallbacks_1_1_v_m_e_search_view_callback_aed797193860b9e42ed353dd029dfc0b1.html#aed797193860b9e42ed353dd029dfc0b1", null ],
      [ "searchViewDidCancel", "interfacecallbacks_1_1_v_m_e_search_view_callback_a5fc53c3bada9aade5a3ceb5c8c750a59.html#a5fc53c3bada9aade5a3ceb5c8c750a59", null ]
    ] ]
];