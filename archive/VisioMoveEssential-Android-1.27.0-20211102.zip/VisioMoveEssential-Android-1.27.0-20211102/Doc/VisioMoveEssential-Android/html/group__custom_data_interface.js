var group__custom_data_interface =
[
    [ "fetchCustomData", "group__custom_data_interface_gaca51c94cebf42b78f86c115bf2dc5f5d.html#gaca51c94cebf42b78f86c115bf2dc5f5d", null ],
    [ "getCustomData", "group__custom_data_interface_ga97b35655817cfd51cbc564319605ca00.html#ga97b35655817cfd51cbc564319605ca00", null ]
];