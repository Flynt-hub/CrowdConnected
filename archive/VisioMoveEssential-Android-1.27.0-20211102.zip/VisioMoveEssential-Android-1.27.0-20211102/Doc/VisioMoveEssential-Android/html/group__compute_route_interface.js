var group__compute_route_interface =
[
    [ "computeRoute", "group__compute_route_interface_ga5322c2407c78ef61198d8367b8ab77b2.html#ga5322c2407c78ef61198d8367b8ab77b2", null ],
    [ "getAttributes", "group__compute_route_interface_ga8f883b7f94ba0e5cc83225ffb5ea2b3b.html#ga8f883b7f94ba0e5cc83225ffb5ea2b3b", null ],
    [ "getModalities", "group__compute_route_interface_ga011b08f413edce60d9d16589ae105ed1.html#ga011b08f413edce60d9d16589ae105ed1", null ],
    [ "setExcludedAttributes", "group__compute_route_interface_ga14a048017d171619bc22cf24071fdc70.html#ga14a048017d171619bc22cf24071fdc70", null ],
    [ "setExcludedModalities", "group__compute_route_interface_ga9816fe68bec162a1cce32ef29d89d219.html#ga9816fe68bec162a1cce32ef29d89d219", null ]
];