var group__place_info_inteface =
[
    [ "addPlace", "group__place_info_inteface_gaab34ce1e955ed21f84dff0ef42de3bfa.html#gaab34ce1e955ed21f84dff0ef42de3bfa", null ],
    [ "addPlace", "group__place_info_inteface_gadf780b82b17565f44b97cb14e8e76726.html#gadf780b82b17565f44b97cb14e8e76726", null ],
    [ "getCategory", "group__place_info_inteface_ga096a5cdc0d8fd313c5483d269c655ca8.html#ga096a5cdc0d8fd313c5483d269c655ca8", null ],
    [ "getPlace", "group__place_info_inteface_ga05a6506951c11cd4174a252234e15e87.html#ga05a6506951c11cd4174a252234e15e87", null ],
    [ "getPlaceBoundingPositions", "group__place_info_inteface_gaad9e6e7a8b866b668bf09a85eed42347.html#gaad9e6e7a8b866b668bf09a85eed42347", null ],
    [ "getPlacePosition", "group__place_info_inteface_ga618e408503cae6c687a9ec71ac267aca.html#ga618e408503cae6c687a9ec71ac267aca", null ],
    [ "queryAllCategoryIDs", "group__place_info_inteface_gaf76e28d683ec5475505bb06c79ebb386.html#gaf76e28d683ec5475505bb06c79ebb386", null ],
    [ "queryAllPlaceIDs", "group__place_info_inteface_ga62b49d1a649b42bd95e3c61b35751fa2.html#ga62b49d1a649b42bd95e3c61b35751fa2", null ],
    [ "queryPlaces", "group__place_info_inteface_gafa0c55d8e0c5a057af9eea4fd46ad824.html#gafa0c55d8e0c5a057af9eea4fd46ad824", null ],
    [ "removePlace", "group__place_info_inteface_gaba6df1ed3da10f94afee1f51a2ba581e.html#gaba6df1ed3da10f94afee1f51a2ba581e", null ],
    [ "resetPlaceColor", "group__place_info_inteface_gac43c604c6325ca16ee2a7975a91660ca.html#gac43c604c6325ca16ee2a7975a91660ca", null ],
    [ "resetPlaceColor", "group__place_info_inteface_gabbea0e1576b9268de01bf2d74975353d.html#gabbea0e1576b9268de01bf2d74975353d", null ],
    [ "setPlaceColor", "group__place_info_inteface_ga7e0bd4944f3284daf3a19ae862a2558c.html#ga7e0bd4944f3284daf3a19ae862a2558c", null ],
    [ "setPlaceColor", "group__place_info_inteface_ga2683feb647a4e38a8f5a836e7d85ac8c.html#ga2683feb647a4e38a8f5a836e7d85ac8c", null ],
    [ "setPlaceData", "group__place_info_inteface_ga38b33bff1e4ff5636571fa2a27e0810b.html#ga38b33bff1e4ff5636571fa2a27e0810b", null ],
    [ "setPlacePosition", "group__place_info_inteface_gad347480fa50e61b1bb942816b584e82a.html#gad347480fa50e61b1bb942816b584e82a", null ],
    [ "setPlaceSize", "group__place_info_inteface_gad1d9f5873793393edff8f2fd61ca2f7a.html#gad1d9f5873793393edff8f2fd61ca2f7a", null ],
    [ "showPlaceInfo", "group__place_info_inteface_ga484cc3fbecd7baae29ff5392b1c9179f.html#ga484cc3fbecd7baae29ff5392b1c9179f", null ],
    [ "updatePlaceData", "group__place_info_inteface_ga06fe41938513471a6ed049e98fb7d779.html#ga06fe41938513471a6ed049e98fb7d779", null ]
];