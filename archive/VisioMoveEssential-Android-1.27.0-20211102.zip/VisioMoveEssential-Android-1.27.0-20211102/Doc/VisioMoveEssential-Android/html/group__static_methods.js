var group__static_methods =
[
    [ "getDataSDKVersion", "group__static_methods_gaac2da27fbee70288c68e37549ddd352c.html#gaac2da27fbee70288c68e37549ddd352c", null ],
    [ "getMinDataSDKVersion", "group__static_methods_ga5311e8978daf47c59717188d30dfca9a.html#ga5311e8978daf47c59717188d30dfca9a", null ],
    [ "getVersion", "group__static_methods_gad463592f1516b9e0fbf5431e324cdf1b.html#gad463592f1516b9e0fbf5431e324cdf1b", null ]
];