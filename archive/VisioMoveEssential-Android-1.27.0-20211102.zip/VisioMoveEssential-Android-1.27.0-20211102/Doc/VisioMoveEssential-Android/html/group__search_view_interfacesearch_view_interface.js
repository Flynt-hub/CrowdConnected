var group__search_view_interfacesearch_view_interface =
[
    [ "showSearchViewWithTitle", "group__search_view_interfacesearch_view_interface_ga0a65d9e33c8c818e8a6514834f0e11c4.html#ga0a65d9e33c8c818e8a6514834f0e11c4", null ]
];