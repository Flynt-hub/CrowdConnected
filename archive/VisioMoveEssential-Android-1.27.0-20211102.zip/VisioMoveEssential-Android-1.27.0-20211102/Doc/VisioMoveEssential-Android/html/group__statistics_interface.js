var group__statistics_interface =
[
    [ "getStatisticsTrackedPlaceIDs", "group__statistics_interface_ga94e3e22e31da9741a7652dcdf406716c.html#ga94e3e22e31da9741a7652dcdf406716c", null ],
    [ "isStatisticsLog", "group__statistics_interface_ga7e22daeba66a4f3627d3bb7869366af0.html#ga7e22daeba66a4f3627d3bb7869366af0", null ],
    [ "isStatisticsLogCamera", "group__statistics_interface_ga0f7ed6a0d9957202a5dcd618cbadf7fb.html#ga0f7ed6a0d9957202a5dcd618cbadf7fb", null ],
    [ "isStatisticsLogInterest", "group__statistics_interface_ga511eb329abf75d4e7f5545f9b999b3d4.html#ga511eb329abf75d4e7f5545f9b999b3d4", null ],
    [ "isStatisticsLogLocation", "group__statistics_interface_gaa5f698868adef74dae8f79d7b87ad588.html#gaa5f698868adef74dae8f79d7b87ad588", null ],
    [ "setStatisticsLog", "group__statistics_interface_gad9cfc38a07a793d6af6030059fbb1712.html#gad9cfc38a07a793d6af6030059fbb1712", null ],
    [ "setStatisticsLogCamera", "group__statistics_interface_gae3af714d254bf70a71ee67211867958a.html#gae3af714d254bf70a71ee67211867958a", null ],
    [ "setStatisticsLogInterest", "group__statistics_interface_ga9048f2316e28247c3c7c82508b85491f.html#ga9048f2316e28247c3c7c82508b85491f", null ],
    [ "setStatisticsLogLocation", "group__statistics_interface_gaa61c0a79a73d840ebdd8ade919a6b944.html#gaa61c0a79a73d840ebdd8ade919a6b944", null ],
    [ "setStatisticsTrackedPlaceIDs", "group__statistics_interface_ga1349a4195774c0c8fe318fd77ab6b904.html#ga1349a4195774c0c8fe318fd77ab6b904", null ]
];