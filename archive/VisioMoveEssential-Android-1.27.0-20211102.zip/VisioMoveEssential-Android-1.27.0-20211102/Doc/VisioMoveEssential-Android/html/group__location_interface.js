var group__location_interface =
[
    [ "createLocationFromLocation", "group__location_interface_ga54b306512632b5528146f54c050e2a35.html#ga54b306512632b5528146f54c050e2a35", null ],
    [ "createPositionFromLocation", "group__location_interface_gaecee96ce3cdedab16bc39843c4a00792.html#gaecee96ce3cdedab16bc39843c4a00792", null ],
    [ "getLocationTrackingButtonToggleModes", "group__location_interface_ga10cf0840d40e580f027867cb3293374d.html#ga10cf0840d40e580f027867cb3293374d", null ],
    [ "getLocationTrackingMode", "group__location_interface_gaca800cd328b75d418f5b05f5f61774e1.html#gaca800cd328b75d418f5b05f5f61774e1", null ],
    [ "setLocationTrackingButtonToggleModes", "group__location_interface_gafc646fb2467099624a84d79543cb2808.html#gafc646fb2467099624a84d79543cb2808", null ],
    [ "setLocationTrackingMode", "group__location_interface_ga8c621709fc7251aaff5fddd0971465a6.html#ga8c621709fc7251aaff5fddd0971465a6", null ],
    [ "updateLocation", "group__location_interface_gac643996e9788524af390c7c8b5d0b078.html#gac643996e9788524af390c7c8b5d0b078", null ]
];